'use strict';

let str = 'My favorite number is';

console.log(str, 5);