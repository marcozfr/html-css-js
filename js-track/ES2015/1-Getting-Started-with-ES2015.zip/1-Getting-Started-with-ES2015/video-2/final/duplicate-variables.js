'use strict';

const student = { name: 'Ken' };
var student = { name: 'James' };

console.log(student);