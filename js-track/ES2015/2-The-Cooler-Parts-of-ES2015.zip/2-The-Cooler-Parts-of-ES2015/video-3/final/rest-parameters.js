'use strict';

function myFunction(...params) {
  console.log(params);
}

myFunction('Andrew', 1, 2, 3, 4, 'Ken');