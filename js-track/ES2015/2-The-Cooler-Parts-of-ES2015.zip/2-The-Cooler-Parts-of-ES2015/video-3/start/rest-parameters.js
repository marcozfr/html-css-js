'use strict';

function myFunction(name, ...params) {
  console.log(name, params);
}