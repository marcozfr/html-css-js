'use strict';

function greet(name, timeOfDay) {
  console.log(`Good ${timeOfDay}, ${name}!`);
}