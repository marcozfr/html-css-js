'use strict';

let widgets = ['widget1', 'widget2', 'widget3', 'widget4', 'widget5'];